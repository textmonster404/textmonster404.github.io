NESten 0.61 Beta 1: Readme.txt                             11/02/01

Written by Brad "Zophar" Levicoff for TNSe

------------
Introduction
------------

NESten actually started as a fruit & vegetables emulator. Titled M.U.R.D.E.R
(My unnamed rodent didn't eat rice), this was a test to see how long it would
be before cavities would develop in the human mouth. Actually, wait, no. The
term "NESten" is a Norwegian word for "almost". Therefore, NESten is "Almost
NES". Get it? Didn't think so.

The project began as a test to see how well emulation of the NES could be
done in Delphi. Amazingly enough, the emulator can run full speed on a P166
MMX (with sound enabled, a decent video card is recommended).

If you don't like the emulator, you're welcome to try out other emulators,
such as N'tendo, iNES and Pretendo.

---------------
Version History
---------------

See whatsnew.txt

-------------------
Supporting Features 
-------------------

- Ability to play NSFs (NES sound files). 
- Save States (Standardized NES save state SS?)
- Movie recording (NESten's own format: SM?)
- 4 player support
- Fast Scanline based renderer
- SRAM saving
- Emulates all NES sound channels:
   Square 1
   Square 2
   Triangle
   Noise (not 100% perfect)
   DMC (including RAW PCM support)
   External Channel (for some Japanese games)
- Support for all controllers that support DirectInput (up to 4)
- WAV logging
- Cheat finder
- Mapper plugins
- Multiple palette support (just load a .PAL file)
- And so much more, your brain will freeze over!

--------------------------
Unsupported & Known issues
--------------------------

- Timing is not perfect
- Not all mappers are emulated perfectly.
- No extra peripheral support (lightgun, powerglove, who cares anyway?)
- If you have less than a P-2 266, you won't have too much fun

--------------------
Working the emulator
--------------------

To have fun playing with yourself in NESten, you should have a P200 or higher
(P200+ is recommended for playing with sound). The following should help you
learn how to run the emulator in the event that you have a brain lock and
can't figure it out on your own. ;) Having said that...

File Menu:
- Load ROM
   This opens up the NESten Load Dialogue where you may load a ROM or NSF, as
   well as get information on the many mappers that NESten supports. This
   menu is more informative than the generic load dialog.
- Load Dialog
   The generic load dialog for NESten. Fans of iNES and BioNES will recognize
   it. You can load NSFs and ROMs through this as well.
- Unload ROM
   Frees the currently loaded ROM from memory.
- Priorities
   Use this option to change the priorities for the core & rendering engine,
   and the sound core. If you notice NESten lagging when many programs are
   open, you'll want to set these higher.
- Reset Configuration
   Click on this, and you will reset NESten to its default configuration.
- Quit
   Use "Quit" to open up the ROM downloading script. Works in conjunction with
   Alt + F4 in mIRC. ... actually, it just quits the emulator.

CPU Menu:
- Run
   Starts emulation. Useful if you just hit "Stop" and want to resume the
   game.
- Stop
   Stops emulation. Useful if you find the need to pause the game to take a
   quick leak.
- Save State
   Saves the game's state in .SS? format.
- Load State
   Loads the game's state in .SS? format.
- Prev Slot
   Changes the save state slot to the previous slot.
- Next Slot
   Changes the save slot to the next slot.
- Incremental Saving
   With Incremental Saving on, every time you save state it automatically
   changes to the next slot without asking. Quite useful. (TNSe made me say
   that.)
- Record Movie
   Records a NES movie of you playing with yourself in .SM? format.
- Play Movie
   Plays a NES movie of you playing with yourself in .SM? format.
- Stop Movie
   Stops a NES movie of you... ahh you get the point.
- Hard Reset
   Resets the game as if you had just turned off the NES.
- Soft Reset
   Resets the game as if you had just pushed the 'reset' button on the NES.
   Must be used on some games to perform switching of game.
- Use Interpretive Core (DISABLED)
   Choosing this option will allow NESten to use the slower core. Useful in
   rare cases where there's a bug with the recompiling core.
- Show illegal ops
   Allows NESten to display illegal opcode messages when it hits them.
- Timing
   This option is for advanced users who wish to fiddle with the NES's
   timing.
- Cheat Console
   Allows you to enter Game Genie codes & use the cheat-finder. See cheat.txt
   for more information. (To be written)

Video Menu:
- Select Plugin
   Here you select which plugin you want to use to render the final image.
   The plugins allow for using different interfaces and effects. You must
   close & restart NESten before the new plugin you selected is enabled.
- Configure Plugin
   Here you can configure your plugin of choice.
- NESten Float mode
   Allows NESten to 'float' when focus is not on it. Similar to 'always on 
   top'.
- Sleep while Sync'ing
   Helps preserve CPU by NESten not using as much CPU while vsync is on.
- Sync
   Allows you to choose how NESten syncs itself: 60FPS, 50 FPS, monitor refresh
   rate, or off. 60 FPS is recommended for all NTSC games, 50 FPS for PAL.
- Size
   Allows you to choose 1X or 2X size windowed mode. "Maintain Aspect Ratio on
   Stretch" allows you to stretch the window without distorting the ratio.
- Skip
   Lets NESten skip frames. This should never be set on unless you have a very
   slow computer and find NESten dragging along. 
   (Hardware upgrade recommended instead :)
- Render Background & Render Sprites.
   Purely for debug, why you would wanna disable this beats me.
- 256X224 (NTSC)
   This should always be on unless you're playing PAL games. NTSC games played 
   with this setting off will result in the top part and lower part of the
   screen not being clipped, which can look weird.
- Palette Console
   This option opens the Palette Console.
   The Palette console allows you to load a different palette, modify a palette,
   save a palette etc. You can choose from the ones that come with NESten or 
   you can create one yourself.

Sound Menu:
- Enabled
   Enables sound. Should always be on unless you have a very slow computer or 
   a hearing disability.
- Buffers
   Changes the sound buffering numbers. Only tinker with this setting if you 
   find your sound crackling or lagging (useful for crappy $5 SB clones).
- Channels
   Lets you choose which channels to turn on/off. Useful if you're bored, or if
   a particular channel sounds strange and you want to submit a bug report.
- Start / Stop Logging to WAV
   You can log any NES tune to WAV with this option on. Be warned, however, 
   44100Hz 8 bit mono WAVs do take up a bit of space. Time to break out the MP3
   encoder.

Input Menu:
- Player 1 input
   Allows you to select the keyboard or joystick controls and configure them 
   for player 1.
- Player 2 input
   See above.
- Player 3 input
   See the above "See above".
- Player 4 input
   See above the "See the above"'s See above.

View Menu:
- Stats
   Displays FPS (frames-per-second) counter and total frames counter.
- Debugger
   Opens the Debugger window.
- Info
   Opens the Info window that displays ROM header information such as PRG/CHR
   size and mapper #.
- Recompiler Data (DISABLED)
   Displays Recompiler Data. (Right-Click on one to make a .DMP file)
- NSF control
   Allows you to change between different tracks in an NSF file.
- About
   Opens the about window which displays version #, contact information and 
   thank-yous.

-----------
Coming Soon
-----------
- To be announced

-------------------------------------
Thanks and Greetings to the following
-------------------------------------

Zophar - For writing the documentation, beta-testing at 4 in the morning, and
hosting the official NESten homepage @ tnse.zophar.net. Be sure to visit 
www.zophar.net for all your emulation needs.

WARNING: These names have been put in a RANDOM order by a semi-sentient program!

A big thanks to The Quietust for reimplementing all the mappers in a much more
structured way. Also big thanks to kevtris for getting detailed information about
a lot of the mappers.

Repulse, nyef, Jabo, y0shi, [_TRAC_], Neill1712, MickoZ, /Firebug/, Tom-Servo, Niiru,
][ellbent, Azimer, orkim, Bananmos, [Vector], SnowBro, _Bnu, Crix0r, 
Memblers, Lycia, ReaperSMS, W1k, TwoBear, c003y, EFX, loopy, JL_Picard, Quietust,
Destop, NeoBlaze, {Slime}
... And the rest I forgot to type in. (or they change nicks so often 
that I don't remember it :P) (and to make the bots happy, |2099| and Jaellyn)


AND ALL YOU OTHER ON #n(letters left out,private channel),
#sn(yet another private channel), #ZopharsDomain, #kinox. 
AND YOU. YES EVEN YOU :)  
  
-------
Contact
-------

You can reach TNSe at TNSeOWNZ@zophar.net
You can reach Quietust at quietust@ircN.org.com

Official Homepage located at: http://tnse.zophar.net
Bug reports can be posted on the NESten messageboard.

-- EOF --